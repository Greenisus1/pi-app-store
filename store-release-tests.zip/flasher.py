"""Read-only device scan and guarded official Pi Imager CLI invocation."""
import hashlib,json,os,pathlib,re,shutil,subprocess

def candidates(tree):
    out=[]
    def mounted(node):
        return bool(node.get('mountpoint') or any(node.get('mountpoints') or [])) or any(mounted(c) for c in node.get('children',[]))
    for disk in tree.get('blockdevices',[]):
        if disk.get('type')!='disk' or disk.get('ro') or not disk.get('rm') or mounted(disk):continue
        if not re.fullmatch(r'/dev/[A-Za-z0-9]+',disk.get('path','')):continue
        out.append(disk)
    return out

def scan(run=subprocess.run):
    result=run(['lsblk','--json','--bytes','--paths','--output','PATH,TYPE,SIZE,RM,RO,MOUNTPOINTS,MODEL,SERIAL'],check=True,capture_output=True,text=True)
    return candidates(json.loads(result.stdout))

def flash(image,device,ask=input,run=subprocess.run):
    image=pathlib.Path(image).resolve(strict=True)
    if not image.is_file() or image.suffix.lower()!='.img':raise ValueError('Choose an extracted local .img file. Remote images/compressed files not supported by this guarded flow.')
    if not shutil.which('rpi-imager'):raise ValueError('Install Raspberry Pi Imager first from Other software.')
    rows=scan(run);selected=next((d for d in rows if d['path']==device),None)
    if not selected:raise ValueError('Drive is not a removable unmounted writable disk. Root/mounted drives rejected.')
    if image.stat().st_size>int(selected['size']):raise ValueError('Image is larger than drive.')
    digest=hashlib.sha256()
    with image.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):digest.update(chunk)
    print('Image:',image,'\nDrive:',device,'\nModel:',selected.get('model'),'\nSerial:',selected.get('serial'),'\nSize:',selected['size'],'bytes\nALL DATA ON THIS DRIVE WILL BE ERASED.\nVerification remains enabled.')
    if ask('Type ERASE '+device+' to continue: ')!='ERASE '+device:return False
    # Re-check after review to catch mounts/device replacement. Serial/size must remain identical.
    fresh=next((d for d in scan(run) if d['path']==device),None)
    if not fresh or any(fresh.get(k)!=selected.get(k) for k in ('serial','size','model')):raise ValueError('Drive state changed. Nothing written.')
    cmd=['rpi-imager','--cli','--sha256',digest.hexdigest(),str(image),device]
    if os.geteuid()!=0:
        if not shutil.which('sudo'):raise ValueError('Root privileges required.')
        cmd=['sudo']+cmd
    run(cmd,check=True)
    return True

def menu():
    try:
        disks=scan()
        if not disks:print('No removable unmounted writable disks available. Mounted/boot disks are not offered.');return
        for d in disks:print(d['path'],d.get('model'),d['size'],'bytes')
        flash(input('Extracted .img path: '),input('Exact target /dev/...: '))
    except (OSError,ValueError,subprocess.SubprocessError) as exc:print('Flashing stopped:',exc)
