import pathlib,tempfile,unittest,json
import settings
class Tests(unittest.TestCase):
 def test_defaults(self):
  with tempfile.TemporaryDirectory() as d:self.assertEqual(settings.load(pathlib.Path(d)/'x'),settings.DEFAULTS)
 def test_persist(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'x';a=dict(settings.DEFAULTS,theme='light');settings.save(p,a);self.assertEqual(settings.load(p),a);self.assertEqual(p.stat().st_mode&0o777,0o600)
 def test_invalid_preserves_old(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'x';settings.save(p,settings.DEFAULTS)
   with self.assertRaises(ValueError):settings.save(p,dict(settings.DEFAULTS,theme='blue'))
   self.assertEqual(settings.load(p),settings.DEFAULTS)
 def test_bad_json(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'x';p.write_text('{bad')
   with self.assertRaises(ValueError):settings.load(p)
 def test_wrong_update_type(self):
  with tempfile.TemporaryDirectory() as d:
   with self.assertRaises(ValueError):settings.save(pathlib.Path(d)/'x',dict(settings.DEFAULTS,update_on_boot='yes'))
if __name__=='__main__':unittest.main()
