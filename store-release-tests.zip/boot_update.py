"""Opt-in systemd oneshot for Store self-update only, preserving account identity."""
import os,pathlib,pwd,re,shlex,subprocess
NAME='pi-app-store-self-update.service'

def unit(program,home,user):
    if not re.fullmatch(r'[a-z_][a-z0-9_-]*|root',user):raise ValueError('Invalid account name.')
    program=pathlib.Path(program).resolve();home=pathlib.Path(home).resolve()
    # systemd quote grammar differs from shell; reject newline/percent/backslash/quote paths.
    if any(c in str(program)+str(home) for c in '\n\r%\\"'):raise ValueError('Unsupported service path.')
    return '[Unit]\nDescription=Pi App Store self-update (opt-in)\nWants=network-online.target\nAfter=network-online.target\n\n[Service]\nType=oneshot\nUser='+user+'\nEnvironment="HOME='+str(home)+'"\nExecStart=/usr/bin/python3 "'+str(program)+'" --boot-self-update\nTimeoutStartSec=90\nNoNewPrivileges=true\n\n[Install]\nWantedBy=multi-user.target\n'

def set_enabled(enabled,program,home,run=subprocess.run):
    if os.geteuid()!=0:raise ValueError('Boot update setup requires root. No privilege prompt/automatic sudo here.')
    path=pathlib.Path('/etc/systemd/system')/NAME
    user=pwd.getpwuid(os.geteuid()).pw_name
    if enabled:
        content=unit(program,home,user)
        if path.exists() and 'Pi App Store self-update (opt-in)' not in path.read_text():raise ValueError('Existing unrelated service not replaced.')
        path.write_text(content);run(['systemctl','daemon-reload'],check=True);run(['systemctl','enable',NAME],check=True)
        # enable only, never start now.
    else:
        if path.exists() and 'Pi App Store self-update (opt-in)' not in path.read_text():raise ValueError('Existing unrelated service not removed.')
        run(['systemctl','disable',NAME],check=True)
        if path.exists():path.unlink()
        run(['systemctl','daemon-reload'],check=True)
