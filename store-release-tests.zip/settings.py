"""Private persistent preferences. No startup effects without explicit enable."""
import json,os,pathlib,tempfile
DEFAULTS={'schema':1,'theme':'dark','update_on_boot':False,'autorun':[]}

def load(path):
    p=pathlib.Path(path)
    if not p.exists():return dict(DEFAULTS,autorun=[])
    try:data=json.loads(p.read_text())
    except (OSError,ValueError) as exc:raise ValueError('Cannot read settings: '+str(exc)) from None
    if not isinstance(data,dict):raise ValueError('Settings must be an object.')
    theme=data.get('theme','dark');update=data.get('update_on_boot',False);autorun=data.get('autorun',[])
    if theme not in ('light','dark') or not isinstance(update,bool) or not isinstance(autorun,list) or not all(isinstance(n,str) and n for n in autorun):raise ValueError('Invalid settings values.')
    return dict(DEFAULTS,theme=theme,update_on_boot=update,autorun=autorun)

def save(path,data):
    path=pathlib.Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    # Validate through same parser without touching existing preference file.
    fd,tmp=tempfile.mkstemp(prefix='.settings-',dir=path.parent)
    try:
        with os.fdopen(fd,'w') as stream:json.dump(data,stream,indent=2);stream.write('\n')
        clean=load(tmp)
        pathlib.Path(tmp).write_text(json.dumps(clean,indent=2)+'\n');os.chmod(tmp,0o600);os.replace(tmp,path)
        return clean
    finally:
        try:os.unlink(tmp)
        except FileNotFoundError:pass
