"""Opt-in interactive terminal login hook. No unattended menus or privileged service."""
import pathlib,shlex
START='# BEGIN PI APP STORE LOGIN'
END='# END PI APP STORE LOGIN'

def update_profile(text,program,enable):
    if text.count(START)!=text.count(END) or text.count(START)>1 or (START in text and text.index(START)>text.index(END)):raise ValueError('Ambiguous existing login hook; edit manually.')
    if START in text:
        a=text.index(START);b=text.index(END,a)+len(END)
        text=text[:a]+text[b:].lstrip('\n')
    if not enable:return text
    block=START+'''\n# Interactive visible terminals only. Never run over a noninteractive SSH command.
if [ -t 0 ] && [ -t 1 ] && [ -n "${PS1:-}" ] && [ "${PI_APP_STORE_LOGIN_ACTIVE:-0}" != 1 ]; then
  export PI_APP_STORE_LOGIN_ACTIVE=1
  python3 '''+shlex.quote(str(pathlib.Path(program).resolve()))+''' --login-start
fi
'''+END+'\n'
    return text.rstrip('\n')+'\n\n'+block

def install_hook(home,program,enable):
    home=pathlib.Path(home)
    profile = next((home/n for n in ('.bash_profile', '.bash_login', '.profile') if (home/n).exists() or (home/n).is_symlink()), home/'.profile')
    if profile.is_symlink():raise ValueError('Profile symlink not changed automatically.')
    old=profile.read_text() if profile.exists() else ''
    new=update_profile(old,program,enable)
    backup=profile.with_name(profile.name+'.pi-app-store-backup')
    if profile.exists() and not backup.exists():backup.write_text(old);backup.chmod(0o600)
    profile.write_text(new)
    return profile
